G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*
G04 #@! TF.CreationDate,2026-05-10T11:29:10-07:00*
G04 #@! TF.ProjectId,Power Button,506f7765-7220-4427-9574-746f6e2e6b69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-05-10 11:29:10*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.190500X-0.762000X-0.444500X0.762000X-0.444500X0.762000X0.444500X-0.762000X0.444500X0*%
%ADD11C,1.750000*%
%ADD12C,4.000000*%
%ADD13C,2.500000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,REF\u002A\u002A*
X103310000Y-42320000D03*
X108710000Y-42320000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,S1*
X99060000Y-59690000D03*
D12*
X104140000Y-59690000D03*
D11*
X109220000Y-59690000D03*
D13*
X100330000Y-57150000D03*
X106680000Y-54610000D03*
G04 #@! TD*
M02*
